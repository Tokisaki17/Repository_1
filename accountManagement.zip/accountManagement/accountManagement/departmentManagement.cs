﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;
using System.Xml.Linq;

namespace accountManagement
{
    public class DepartmentManagement
    {
        //global variables
        private string _department; private string _budget; private decimal _budgetDecimal;
        DepManagement departments = new EditDepartment();
        public void Create(string departmentName, decimal budget) //creates department
        {
            _department = departmentName;
            _budgetDecimal = budget;
            departments.CreateDep(_department, _budgetDecimal);
        }

        public void Delete(string departmentName, string budget) //deletes department
        {
            _department = departmentName;
            _budget = budget;
            departments.DeleteDep(_department, _budget); 
        }
        public string GetDepartmentName(string filepath) //gets department name for searching purposes
        {
            return departments.MakeList(filepath);
        }
    }
}
