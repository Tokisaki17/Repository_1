﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Xml.Linq;

namespace accountManagement
{
    public class Useraccount
    {
        private string _name; private string _pos; private string _password;
        private string _confirmName; private string _newPassword; private string _confirmPos;
        UserAccount user = new AbsClassUseraccount();
        public void CreateAcc(string name, string pass, string role) //create an account by manager only
        {
            _name = name;
            _password = pass;
            _pos = role;
            user.Create(_name, _password, _pos);
        }
        public void UpdateAcc(string currentName, string oldPassword, string currentRole, string name, string newPassword, string role) //updates an account by manager only
        {
            _name = currentName;
            _password = oldPassword;
            _pos = currentRole;
            _confirmName = name;
            _newPassword = newPassword;
            _confirmPos = role;
            user.Update(_name, _password, _pos, _confirmName, _newPassword, _confirmPos);
        }
        public string[] Reads(string name, string pass, string role) //reads the file if it contains the user
        {
            _name = name;
            _password = pass;
            _pos = role;
            return user.Read(_name, _password, _pos);
        }
        public void Activate(string name, string pass, string role) //account activation
        {
            _name = name;
            _password = pass;
            _pos = role;
            user.Activation(_name, _password, _pos);
        }
    }
}
