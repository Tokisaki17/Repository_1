﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace accountManagement
{
    //files
    class Filed
    {
        public static string FilePath(string filepath)
        {
            // Create a DirectoryInfo object for the current directory
            string directory = AppDomain.CurrentDomain.BaseDirectory; //file location of the dll
            DirectoryInfo nameDirectory = new DirectoryInfo(directory); //creation

            DirectoryInfo binNameDirectory = nameDirectory.Parent; //parent of directory (fullpath of the file dll)
            DirectoryInfo exitBin = binNameDirectory.Parent; //parent of bin.

            string exitBinPath = exitBin.FullName;
            string dataCreation = Path.Combine(exitBinPath, "Resources\\", filepath);

            return dataCreation;
        }
    }
    //user accounts
    abstract class UserAccount
    {
        public abstract void Create(string name, string pass, string role);
        public abstract void Update(string currentName, string oldPassword, string currentRole, string name, string newPassword, string role);
        public abstract string[] Read(string name, string pass, string role);
        public abstract void Activation(string name, string pass, string role);

    }
    class AbsClassUseraccount : UserAccount
    {
        //private string _correct;
        public override void Create(string name, string pass, string role)
        {
            string user = name + "," + pass + "," + role + ",activate"; //default to activation
            if (File.Exists(Filed.FilePath("data.txt")))
            {
                var userContents = File.ReadAllLines(Filed.FilePath("data.txt")).Where(l => !string.IsNullOrWhiteSpace(l)).Select(l => l.Trim()).ToList(); //lists all contents in the file
                if (userContents.Any(userContent => userContent.Contains(name))) //throuws exception if user already exists, avoiding 2 same user accounts
                {
                    throw new Exception("User already exists");
                }
                else
                {
                    File.AppendAllText(Filed.FilePath("data.txt"), "\n" + user); //appends a new user
                    userContents = File.ReadAllLines(Filed.FilePath("data.txt")).Where(l => !string.IsNullOrWhiteSpace(l)).Select(l => l.Trim()).ToList();
                    File.WriteAllLines(Filed.FilePath("data.txt"), userContents);
                }
            }

            else
            {
                File.WriteAllText(Filed.FilePath("data.txt"), user); //creates file if file not found
            }
        }
        public override void Update(string currentName, string oldPassword, string currentRole, string name, string newPassword, string role) 
        {
            string user = currentName + "," + oldPassword + "," + currentRole; //user details inputted
            string updatedUser = name + "," + newPassword + "," + role; //updated password and confirmed user details

            if (File.Exists(Filed.FilePath("data.txt")))
            {
                string[] updateFile = File.ReadAllLines(Filed.FilePath("data.txt")); //reads all lines, getting the file so that it can be updated later on.
                for (int i = 0; i < updateFile.Length; i++)
                {
                    if (updateFile[i].Contains(user)) //updates the user in the file found
                    {
                        updateFile[i] = updateFile[i].Replace(user, updatedUser);
                    }
                }
                File.WriteAllLines(Filed.FilePath("data.txt"), updateFile); //writes all lines back to the file
            }
            else //throws an exception if there is a problem with the file
            {
                throw new Exception("Invalid! There seems to be a problem with the file or doesn't exists!");
            }
        }
        public override string[] Read(string name, string pass, string role) //reads file for confirmation and login purposes
        {
            string user = name + "," + pass + "," + role; //user
            string[] readfile;
            if (File.Exists(Filed.FilePath("data.txt")))
            {
                readfile = File.ReadAllLines(Filed.FilePath("data.txt")); //reads all lines
                for (int i = 0; i < readfile.Length; i++)
                {
                    if (readfile[i].Contains(user)) //if the user is found
                    {
                        return new string[] { "true" };
                    }
                }
            }
            else //throws an exception if there is a problem with the file
            {
                throw new Exception("Invalid! There seems to be a problem with the file or doesn't exists!");
            }
            return readfile; //returns if user not found
        }
        
        public override void Activation(string name, string pass, string role) //Activate/deactivate account. Will only execute if the user exists and it is the opposite of the activation type
        {
            if (File.Exists(Filed.FilePath("data.txt")))
            {
                string user = name + "," + pass + "," + role + ",activate"; //user is activated
                string[] filepath = File.ReadAllLines(Filed.FilePath("data.txt"));
                for (int i = 0; i < filepath.Length; i++)
                {
                    if (filepath[i].Contains(user))
                    {
                        filepath[i] = filepath[i].Replace("activate", "deactivate"); //deactivates
                        File.WriteAllLines(Filed.FilePath("data.txt"), filepath);
                    }
                    else
                    {
                        string deactivateUser = name + "," + pass + "," + role + ",deactivate"; //user is deactivated
                        if (filepath[i].Contains(deactivateUser))
                        {
                            filepath[i] = filepath[i].Replace("deactivate", "activate"); //activates
                            File.WriteAllLines(Filed.FilePath("data.txt"), filepath);
                        }
                    }
                }
            }
            else //throws an exception if there is a problem with the file
            {
                throw new Exception("Invalid! There seems to be a problem with the file or doesn't exists!");
            }
        }
    }
    abstract class DepManagement //department management
    {
        public abstract void CreateDep(string departmentName, decimal budget);
        public abstract void DeleteDep(string departmentName, string budget);
        public abstract string MakeList(string filepath);

    }
    class EditDepartment : DepManagement
    {
        public override void CreateDep(string departmentName, decimal budget) 
        {
            
            if (File.Exists(Filed.FilePath("departments.txt")))
            {
                var userContents = File.ReadAllLines(Filed.FilePath("departments.txt")); //reads all lines
                if (userContents.Any(userContent => userContent.Contains(departmentName))) //throws exception if department already exists
                {
                    throw new Exception("Department already exists");
                }
                else //adds new department
                {
                    File.AppendAllText(Filed.FilePath("departments.txt"), "\n" + departmentName + "|" + budget);
                }
            }

            else //creates a file if file is not found
            {
                File.WriteAllText(Filed.FilePath("departments.txt"), departmentName + "|" + budget);
            }
        }
        public override void DeleteDep(string departmentName, string budget)
        {
            if (File.Exists(Filed.FilePath("departments.txt")))
            {
                var lines = File.ReadAllLines(Filed.FilePath("departments.txt")).Where(l => !string.IsNullOrWhiteSpace(l)).Select(l => l.Trim()).ToList(); //creates a list for that contains all lines in this file
                string lineToDelete = lines.FirstOrDefault(line => line.Trim().Contains(departmentName)); //finds the line to be deleted
                if (lineToDelete != null) //stricts to only line such that it is not whitespace or null
                {
                    //parse the deleted budget
                    decimal deletedBudget = 0;
                    string[] parts = lineToDelete.Split('|'); //splits the line to be deleted
                    if (parts.Length > 1 && decimal.TryParse(parts[1], out deletedBudget))
                    {
                        lines.Remove(lineToDelete);

                        if (lines.Count > 0)
                        {
                            decimal share = deletedBudget / lines.Count; //amount to share to each department

                            for (int i = 0; i < lines.Count; i++) //loops through each line
                            {
                                string[] data = lines[i].Split('|');
                                if (data.Length > 1 && decimal.TryParse(data[1], out decimal deptBudget)) //parses and updates budget per department
                                {
                                    deptBudget += share;
                                    data[1] = deptBudget.ToString(); //format nicely
                                    lines[i] = string.Join("|", data);
                                }
                            }
                        }

                        File.WriteAllLines(Filed.FilePath("departments.txt"), lines);//rewrites lines back to the source file
                    } 
                }
            }
            else //throws an exception if there is a problem with the file
            {
                throw new Exception("Invalid! There seems to be a problem with the file or doesn't exists!");
            }
        }
        public override string MakeList(string filepath) //returns file path to make a list of departments
        {
            return Filed.FilePath(filepath);
        }
    }
}
