﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace ExpenditureModule
{
    internal class ReadFile
    {
        public static string Readfile(string filepath)
        {
            return ReadFiler(filepath);
        }
        private static string ReadFiler(string filepath)
        {
            // Create a DirectoryInfo object for the current directory
            string directory = AppDomain.CurrentDomain.BaseDirectory; //file location of the dll
            DirectoryInfo nameDirectory = new DirectoryInfo(directory); //creation

            DirectoryInfo binNameDirectory = nameDirectory.Parent; //parent of directory (fullpath of the file dll)
            DirectoryInfo exitBin = binNameDirectory.Parent; //parent of bin.

            string exitBinPath = exitBin.FullName;
            string dataCreation = Path.Combine(exitBinPath, "Resources\\", filepath);

            return dataCreation;
        }
    }
    public class ExpenditureCategory
    {
        public static void CreateExpenditure(string categoryName)
        {
            string filepath = ReadFile.Readfile("expenditurecategory.txt"); 
            if (File.Exists(filepath))
            {
                var content = File.ReadAllLines(filepath);
                if (content.Any(specificContent => specificContent.Equals(categoryName, StringComparison.OrdinalIgnoreCase)) || content.Any(specificContent => specificContent.Equals(categoryName+"s", StringComparison.OrdinalIgnoreCase))) //prevents duplicate expenditure category
                {
                    throw new Exception("Expenditure category already exists.");
                }
                else
                {
                    File.AppendAllText(filepath, "\n" + categoryName); //adds expenditure category
                }
            }
            else
            {
                File.WriteAllText(filepath, categoryName);
            }
        }
        public static string ListCategory(string filepath) //lists all expenditure category by reading the file.
        {
            return ReadFile.Readfile(filepath);
        }
    }
}