﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

namespace ExpenditureModule
{
    class Filer
    {
        public static string Read(string filepath)
        {
            string directory = AppDomain.CurrentDomain.BaseDirectory; //file location of the dll
            DirectoryInfo nameDirectory = new DirectoryInfo(directory); //creation

            DirectoryInfo binNameDirectory = nameDirectory.Parent; //parent of directory (fullpath of the file dll)
            DirectoryInfo exitBin = binNameDirectory.Parent; //parent of bin.

            string exitBinPath = exitBin.FullName;
            string dataCreation = Path.Combine(exitBinPath, "Resources\\", filepath);

            return dataCreation;
        }
    }
    abstract class Expends
    {
        public abstract void NewExpends(string selectDepartment, decimal price, string note, string category, string datetime); //creates expenditures
        public abstract string[] ListBudgets(string filter); //lists all expenditures
        public abstract string[] DataExpend();
        //public abstract void UpdateExpends(string department, string category, string note, string amount, string date, string updateNote, string updateAmount, string updateDate); 
    }
    class Expend : Expends
    {
        public override void NewExpends(string selectDepartment, decimal price, string note, string category, string datetime)
        {
            string filepath = ReadFile.Readfile("departments.txt");
            if (File.Exists(filepath))
            {
                string[] updateFile = File.ReadAllLines(filepath); //reads each line in the file
                foreach (string departments in updateFile) //reads each line in the file and converts into strings
                {
                    if (departments != "") //whitespaces won't include in the loop
                    {
                        string[] list = departments.Split('|'); //splits and separates the character in each line
                        string department = list[0];
                        decimal budget = Convert.ToDecimal(list[1]);
                        if (department.Contains(selectDepartment))
                        {
                            if (price <= 0) //ignores if the price is 0 or lower. It won't allow it.
                            {
                                throw new Exception("Amount can't be equal or lower than 0");
                            }
                            if (budget > 0) //only allows and records if the budget of a department > 0
                            {
                                budget -= price;
                                string newDepartment = department + "|" + budget; //replaces the old line with the new line
                                string parts = $"{department}|{price}|{category}|{datetime}|{note}";
                                string partsHistory = $"{department}|{budget}|{category}|{datetime}|{note}";
                                updateFile = updateFile.Select(line => line == departments ? newDepartment : line).ToArray(); //replaces only the specific line, and then converts it back to array.
                                File.WriteAllLines(filepath, updateFile); //writes all lines found in the updatedFile
                                if (File.Exists(Filer.Read("textfile.txt")) && File.Exists(Filer.Read("textfile2.txt")))
                                {
                                    File.AppendAllText(Filer.Read("textfile.txt"), "\n" + parts); //expense textfile
                                    File.AppendAllText(Filer.Read("textfile2.txt"), "\n" + partsHistory); //budget history

                                }
                                else
                                {
                                    File.WriteAllText(Filer.Read("textfile.txt"), parts); //expense textfile
                                    File.WriteAllText(Filer.Read("textfile2.txt"), partsHistory); //budget history
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                throw new Exception("Invalid! There seems to be a problem with the file or does not exists!");
            }
        }
        public override string[] ListBudgets(string filter)
        {
            string filepath = Filer.Read("textfile.txt");
            if (!File.Exists(filepath)) //returns an empty array. Catching the filenotfounderror
            {
                return Array.Empty<string>();
            }
            var results = new List<string>();
            string[] lines = File.ReadAllLines(filepath); //reads each lines in the file.

            foreach (string line in lines) //reads each lines in the file and converts into strings.
            {
                if (string.IsNullOrWhiteSpace(line))
                { //ignore whitespaces
                    continue;
                }

                //fix search bar bug and add date search
                //filter if the search bar contains such department, empty, or "search department"
                if (string.IsNullOrEmpty(filter) || line.Contains(filter) || filter == "Search Department/Date/Expenditure/Price")
                {
                    results.Add(line); //adds element(departments picked) to the array
                }
            }
            return results.ToArray(); //returns as an array of strings
        }
        public override string[] DataExpend()
        {
            string filepath = Filer.Read("textfile.txt");
            if (File.Exists(filepath))
            {
                var results = new List<string>();
                string[] lines = File.ReadAllLines(filepath); //reads each lines in the file.
                foreach (string line in lines)
                {
                    if (string.IsNullOrWhiteSpace(line))
                    { //ignore whitespaces
                        continue;
                    }
                    results.Add(line); //adds elements to the array
                }
                return results.ToArray();
            }
            else
            {
                return Array.Empty<string>();
            }

        }
        /*        public override void UpdateExpends(string department, string category, string note, string amount, string date, string updateNote, string updateAmount, string updateDate)
                {
                    string filepath = Filer.Read("textfile.txt");
                    if (File.Exists(filepath))
                    {
                        string[] fileRead = File.ReadAllLines(filepath);
                        string lineToFind = $"{department}|{amount}|{category}|{date}|{note}";
                        string lineToReplace = $"{department}|{updateAmount}|{category}|{updateDate}|{updateNote}";
                        foreach (string line in fileRead)
                        {
                            if (string.IsNullOrWhiteSpace(line))
                            {
                                continue;
                            }
                            if (line.Contains(lineToFind))
                            {
                                decimal newAmount = Convert.ToDecimal(updateAmount);

                                string deptFilePath = Filer.Read("departments.txt");

                                if (newAmount != 0)
                                {
                                    string fileDeptPath = Filer.Read("departments.txt");
                                    if (File.Exists(fileDeptPath))
                                    {
                                        string[] deptLines = File.ReadAllLines(fileDeptPath);
                                        for (int i = 0; i < deptLines.Length; i++)
                                        {
                                            string[] parts = deptLines[i].Split('|');
                                            if (parts[0] == department)
                                            {
                                                decimal currentBudget = Convert.ToDecimal(parts[1]);
                                                currentBudget -= newAmount;
                                                deptLines[i] = $"{department}|{currentBudget}";
                                                break;
                                            }
                                        }
                                        File.WriteAllLines(fileDeptPath, deptLines);
                                    }
                                }
                                File.WriteAllLines(filepath, fileRead.Select(l => l == lineToFind ? lineToReplace : l).ToArray());
                                break;
                            }
                        }
                    }
                }*/
    }
}
