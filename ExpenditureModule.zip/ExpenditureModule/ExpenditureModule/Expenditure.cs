﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;


namespace ExpenditureModule
{
    public class Expenditure
    {
        Expends exp = new Expend();
        public void NewSaveExpenditure(string selectDepartment, decimal price, string note, string category, string datetime) //executes computation
        {
            exp.NewExpends(selectDepartment, price, note, category, datetime);
        }

        public string[] ListStringBudget(string filter) //returns string array
        {
            return exp.ListBudgets(filter);
        }
        public string[] DataExpenditures()
        {
            return exp.DataExpend();
        }
        /*public void UpdateExpend(string department, string category, string note, string amount, string date, string updateNote, string updateAmount, string updateDate)
        {
            exp.UpdateExpends(department, category, note, amount, date, updateNote, updateAmount, updateDate);
        }*/
    }
}
