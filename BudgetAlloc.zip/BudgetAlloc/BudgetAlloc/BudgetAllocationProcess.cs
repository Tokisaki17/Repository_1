﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;

namespace BudgetAlloc
{
    public class BudgetAllocationProcess
    {
        Budgetallo alloc = new BudgAlloc();

        public void AllocSaveBudget(string selectDepartment, decimal price, string note, string category, string datetime) //allocates new budget
        {
            alloc.AllocationBudget(selectDepartment, price, note, category, datetime);
        }
        public string[] ListStringBudget(string filter, string file)
        {
            return alloc.ListstringBudget(filter, file);
        }
        /*public string[] ListRemainBudget(string filter)
        {
            return alloc.ListremainBudget(filter);
        }*/
    }
}
