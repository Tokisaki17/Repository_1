﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace BudgetAlloc
{
    class Filed
    {
        public static string Readfile(string filepath)
        {
            return ReadFile(filepath);
        }
        private static string ReadFile(string filepath) //gets file locations
        {
            string directory = AppDomain.CurrentDomain.BaseDirectory; //file location of the dll
            DirectoryInfo nameDirectory = new DirectoryInfo(directory); //creation

            DirectoryInfo binNameDirectory = nameDirectory.Parent; //parent of directory (fullpath of the file dll)
            DirectoryInfo exitBin = binNameDirectory.Parent; //parent of bin.

            string exitBinPath = exitBin.FullName;
            string dataCreation = Path.Combine(exitBinPath, "Resources\\", filepath);

            return dataCreation;
        }
    }
    abstract class Budgetallo
    {
        public abstract void AllocationBudget(string selectDepartment, decimal price, string note, string category, string datetime);
        public abstract string[] ListstringBudget(string filter, string filepath);
        //public abstract string[] ListremainBudget(string filter);
    }
    class BudgAlloc : Budgetallo
    {
        public override void AllocationBudget(string selectDepartment, decimal price, string note, string category, string datetime)
        {
            string _filepath = Filed.Readfile("departments.txt"); //gets the designated path
            if (File.Exists(_filepath)) //only if the file exists
            {
                string[] updateFile = File.ReadAllLines(_filepath);
                foreach (string departments in updateFile) //gets the budget in the textfile
                {
                    if (departments != "")
                    {
                        string[] list = departments.Split('|');
                        string department = list[0];
                        decimal budget = Convert.ToDecimal(list[1]);
                        if (department.Contains(selectDepartment))
                        {
                            if (price <= 0) //won't commence if the inputted price is 0 or lower
                            {
                                throw new Exception("Amount can't be equal or lower than 0.");
                            }
                            budget += price; //adds up the total budget from the price allocated
                            string newDepartment = department + "|" + budget; //replaces the old line with the new line
                            string parts = $"{department}|{budget}|{category}|{datetime}|{note}";
                            updateFile = updateFile.Select(line => line == departments ? newDepartment : line).ToArray(); //replaces only the specific line, and then converts it back to array.
                            File.WriteAllLines(_filepath, updateFile);
                            if (File.Exists(Filed.Readfile("textfile2.txt"))) //textfile for budget allocation history
                            {
                                File.AppendAllText(Filed.Readfile("textfile2.txt"), "\n" + parts);
                            }
                            else
                            {
                                File.WriteAllText(Filed.Readfile("textfile2.txt"), parts);
                            }
                        }
                    }
                }
            }
        }
        public override string[] ListstringBudget(string filter, string file)
        {
            string filepath = Filed.Readfile(file); //gets the designated path
            if (!File.Exists(filepath))
            {
                return Array.Empty<string>(); //returns empty if the file doesn't exist. Catching the filenotfounderror
            }
            var results = new List<string>();
            string[] lines = File.ReadAllLines(filepath); //reads each lines and returns as array

            foreach (string line in lines) //reads each lines in the textfile and converts into string
            {
                if (string.IsNullOrWhiteSpace(line)) //ignores whitespaces
                    continue;

                //filter if the search bar is empty, contains such department, or simply search department
                if (string.IsNullOrEmpty(filter) || line.Contains(filter) || filter == "Search Department/Date/Expenditure/Price")
                {
                    results.Add(line);
                }
            }
            return results.ToArray(); //returns as a string list
        }
        /*public override string[] ListremainBudget(string filter)
        {
            string filepath = Filed.Readfile("departments.txt"); //gets the designated path
            if (!File.Exists(filepath)) //returns empty if the file doesn't exist. Catching the filenotfounderror
            {
                return Array.Empty<string>();
            }
            var results = new List<string>();
            string[] lines = File.ReadAllLines(filepath); //reads each lines and returns as array

            foreach (string line in lines) //reads each lines in the textfile and converts into string
            {
                if (string.IsNullOrWhiteSpace(line)) //ignores whitespaces
                    continue;

                //filter if the search bar is empty, contains such department, or simply search department
                if (string.IsNullOrEmpty(filter) || line.Contains(filter) || filter == "Search Department")
                {
                    results.Add(line);
                }
            }
            return results.ToArray(); //returns as a string list
        }*/
    }
}
