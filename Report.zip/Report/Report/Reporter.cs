﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Report
{
    class Filed
    {
        public static string Readfile(string filepath)
        {
            string directory = AppDomain.CurrentDomain.BaseDirectory; //file location of the dll
            DirectoryInfo nameDirectory = new DirectoryInfo(directory); //creation

            DirectoryInfo binNameDirectory = nameDirectory.Parent; //parent of directory (fullpath of the file dll)
            DirectoryInfo exitBin = binNameDirectory.Parent; //parent of bin.

            string exitBinPath = exitBin.FullName;
            string dataCreation = Path.Combine(exitBinPath, "Resources\\", filepath);

            return dataCreation;
        }
    }
    abstract class Reports
    {
        public abstract string HighDepExp();
        public abstract string LowDepExp();
        public abstract string ReportPercent();
        public abstract decimal AnalyzeSave(decimal budget, decimal monthlyExp, decimal monthlyInc, decimal monthRate, decimal targetMonths, decimal inflation, decimal targetFunds);
        public abstract List<decimal> AnalyzeChart();
    }
    class Reporter : Reports
    {
        private string _budget; private string _department; private decimal _outBudget; public static decimal outExpenses { get; private set; }
        private List<decimal> _cashList = new List<decimal>();
        public override string HighDepExp()
        {
            string filepath = Filed.Readfile("textfile.txt"); //file of expenditures
            if (File.Exists(filepath))
            {
                var result = new Dictionary<string, decimal>();
                string[] fileRead = File.ReadAllLines(filepath);
                foreach (string lines in fileRead)
                {
                    if (string.IsNullOrWhiteSpace(lines))
                    {
                        continue;
                    }
                    string[] linesSplit = lines.Split('|');
                    _department = linesSplit[0];
                    _budget = linesSplit[1];
                    if (linesSplit.Length == 5 && decimal.TryParse(_budget, out _outBudget))
                    {
                        if (decimal.Parse(linesSplit[1]) >= 0)
                        {
                            if (result.ContainsKey(_department))
                            {
                                result[_department] += _outBudget;
                            }
                            else
                            {
                                result[_department] = _outBudget;
                            }
                        }
                    }
                }
                var highestDept = result.OrderByDescending(d => d.Value).FirstOrDefault();
                return highestDept.Key;
            }
            else
            {
                return "";
            }
        }
        public override string LowDepExp()
        {
            string filepath = Filed.Readfile("textfile.txt");
            if (File.Exists(filepath))
            {
                var result = new Dictionary<string, decimal>();
                string[] fileRead = File.ReadAllLines(filepath);
                foreach (string lines in fileRead)
                {
                    if (string.IsNullOrWhiteSpace(lines))
                    {
                        continue;
                    }
                    string[] linesSplit = lines.Split('|');
                    _department = linesSplit[0];
                    _budget = linesSplit[1];
                    if (linesSplit.Length == 5 && decimal.TryParse(_budget, out _outBudget))
                    {
                        if (decimal.Parse(linesSplit[1]) >= 0)
                        {
                            if (result.ContainsKey(_department))
                            {
                                result[_department] += _outBudget;
                            }
                            else
                            {
                                result[_department] = _outBudget;
                            }
                        }
                    }
                }
                var lowestDep = result.OrderBy(d => d.Value).FirstOrDefault();
                return lowestDep.Key;
            }
            else
            {
                return "";
            }
        }
        public override string ReportPercent()
        {
            string filepath = Filed.Readfile("textfile.txt");
            string[] arrayFile = File.ReadAllLines(filepath);
            decimal v = 0; //expenses
            decimal r = 0; //remaining budgets
            foreach (string line in arrayFile)
            {
                if (string.IsNullOrWhiteSpace(line))
                {
                    continue;
                }

                string[] lineSplit = line.Split('|');
                if (decimal.Parse(lineSplit[1]) >= 0)
                {
                    string value = lineSplit[1];
                    decimal expense = decimal.Parse(value);

                    v += expense;
                }
            }
            outExpenses = v;
            filepath = Filed.Readfile("departments.txt");
            arrayFile = File.ReadAllLines(filepath);
            foreach (string line in arrayFile)
            {
                if (string.IsNullOrWhiteSpace(line))
                {
                    continue;
                }

                string[] lineSplit = line.Split('|');
                if (decimal.Parse(lineSplit[1]) >= 0)
                {
                    string value = lineSplit[1];
                    decimal remainBudget = decimal.Parse(value);

                    r += remainBudget;
                }
            }
            decimal total = (r / (r + v)) * 100;
            return Math.Round(total, 2).ToString() + "%";
        }
        public override decimal AnalyzeSave(decimal budget, decimal monthlyExp, decimal monthlyInc, decimal monthRate, decimal targetMonths, decimal inflation, decimal targetFunds) 
        {
            _cashList.Clear();
            _cashList = new List<decimal>();
            int monthReached = -1;
            monthRate = monthRate / 100;
            inflation = inflation / 100;
            for (int i = 0; i < targetMonths; i++)
            {
                decimal income = monthlyInc * (decimal)Math.Pow(1 + (double)monthRate, i);
                decimal expense = monthlyExp * (decimal)Math.Pow(1 + (double)inflation, i);

                budget += (income - expense);
                _cashList.Add(budget);
                /*
                if(budget >= targetFunds)
                {
                    break;
                }
                */

                if (budget >= targetFunds && monthReached == -1)
                {
                    monthReached = i + 1;
                }   
            }
            var lister = _cashList.LastOrDefault();
            return lister;
        }
        public override List<decimal> AnalyzeChart() //returns data in order to create a chart
        {
            return _cashList;
        }
    }
}
