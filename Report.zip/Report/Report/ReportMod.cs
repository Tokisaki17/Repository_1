﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Report
{
    public class ReportMod
    {
        
        Reports report = new Reporter();
        public string rep = Reporter.outExpenses.ToString();
        public string HighestDeptExp()
        {
            return report.HighDepExp();
        }
        public string LeastDeptExp()
        {
            return report.LowDepExp();
        }
        public string ReportPercentage()
        {
            return report.ReportPercent();
        }
        
       public decimal ReportAnalyze(decimal budget, decimal monthlyExp, decimal monthlyInc, decimal monthRate, decimal targetMonths, decimal inflation, decimal targetFunds)
        {
            return report.AnalyzeSave(budget, monthlyExp, monthlyInc, monthRate, targetMonths, inflation, targetFunds);
        }
        public List<decimal> Chart()
        {
            return report.AnalyzeChart();
        }
    }
}
